# CommStack SDK for Node.js

Server-side client for the CommStack messaging platform. Register applications
and users, manage channels and membership, send messages, read history, and
receive messages live as they arrive — all from your own backend, over one
configured address.

Confidential. This package and the documentation it contains are proprietary and
are provided under the terms of the applicable licence agreement.

---

## 1. Requirements and installation

| Requirement | Minimum |
|---|---|
| Node.js | 18.0 |
| TypeScript (optional) | 5.0 |

You were sent a single file, `notify-commstack-sdk-1.2.0.tgz`. It contains the
whole SDK — every operation described in this guide. Put it somewhere in your
project and install it:

```bash
npm install ./notify-commstack-sdk-1.2.0.tgz
```

That adds it to your `package.json` like any other dependency:

```json
"dependencies": {
  "@notify/commstack-sdk": "file:notify-commstack-sdk-1.2.0.tgz"
}
```

Types are bundled — no separate `@types` package is needed, and no other
CommStack package is required.

The package has no dependencies of its own.

<details>
<summary>Building the tarball from source</summary>

```bash
cd sdk
npm install
npm run build:release   # bundled, minified dist/index.js + type declarations
npm pack                # → notify-commstack-sdk-1.2.0.tgz
```

`npm run build` produces readable per-module output instead, which is what the
test suite uses. Run `npm test` to exercise the SDK end to end against an
in-memory server, or point it at a real deployment:

```bash
COMMSTACK_BASE_URL=notcomprodeast.notifync.com \
COMMSTACK_ENV=production \
npm test
```
</details>

## 2. Setup

A client needs three values, and nothing else.

| Value | What it is |
|---|---|
| **`baseUrl`** | The CommStack server you have been allocated, e.g. `notcomprodeast.notifync.com`. The hostname on its own — never a port. |
| **`env`** | Which environment that server is: `'dev'` or `'production'`. |
| **`COMM_STACK_SDK_TOKEN`** | The access token for that deployment, issued to you. Read from the environment, not passed in code. |

```bash
# .env
COMM_STACK_BASE_URL=notcomprodeast.notifync.com
COMM_STACK_ENV=production
COMM_STACK_SDK_TOKEN=<the token you were issued>
```

```ts
import { CommStack } from '@notify/commstack-sdk';

const client = new CommStack({
  baseUrl: process.env.COMM_STACK_BASE_URL!,
  env:     process.env.COMM_STACK_ENV as 'dev' | 'production',
});

await client.verifyAccess();   // throws immediately if anything is wrong
```

Note what is *not* in that constructor: the token. The SDK reads it from the
environment itself, so it never appears in an argument list, a log line or a
stack trace.

### The access token

The token is a secret belonging to your deployment. Put it in the environment
and keep it out of source control.

The SDK looks in three places, first hit wins:

| Order | Source | Use it when |
|---|---|---|
| 1 | `sdkToken` constructor option | You fetch secrets yourself, from a vault or secrets manager |
| 2 | `COMM_STACK_SDK_TOKEN_DEV` / `COMM_STACK_SDK_TOKEN_PRODUCTION` | One process talks to both environments |
| 3 | `COMM_STACK_SDK_TOKEN` | The ordinary case — one deployment per process |

If none is set, the client throws `INVALID_REQUEST` at construction, naming the
variable to set. That is deliberate: a missing token should fail at boot with an
instruction, not later as an unexplained `401`.

> **The token must never reach a browser.** It grants full access to your
> application's data. This is a server-side SDK; see §7 for how to give browser
> and mobile clients live messages without handing them the token.

### The `env` option

`env` names the environment you are talking to. Only `'dev'` and `'production'`
are accepted — a typo, an empty string, a value like `'staging'` throws
`INVALID_REQUEST` the moment the client is constructed, naming the valid values,
so a misconfiguration surfaces at boot rather than as a rejected call later.

It does **not** choose a server: `baseUrl` alone decides which deployment you
reach. `env` only selects which token is read when you keep one per environment.

### How addresses are worked out

Supply the hostname on its own. Everything else — the scheme, the ports, the
`/api/v1` path, and the realtime endpoint — is derived from it. **You never
write a port number, for either protocol.**

```
notcomprodeast.notifync.com   ->   REST      https://notcomprodeast.notifync.com/api/v1
                              ->   realtime  wss://notcomprodeast.notifync.com
```

These forms are all equivalent, and all reach the same deployment:

| You supply | Meaning |
|---|---|
| `notcomprodeast.notifync.com` | a standard deployment — everything filled in |
| `notcomprodeast.notifync.com/` | same, trailing slash ignored |
| `https://notcomprodeast.notifync.com` | same, explicit scheme kept |
| `http://internal-host` | same over plain HTTP |

Any hostname behaves the same way — substitute whichever server you were
allocated. One `baseUrl` covers REST and realtime both; there is no second
address to configure and nothing extra to open in a firewall on your side.

If your deployment sits behind a reverse proxy on a path of its own, give that
address in full — `https://api.example.com/comms/v1` — and the SDK uses it
exactly as written rather than supplying its own layout. Realtime then uses that
same origin.

Everything routes to that one server. A client cannot be retargeted after it is
constructed, so if you integrate with more than one deployment, build one client
per server.

### What about an application id?

`appId` is **not** a constructor option. Applications belong to a server, so you
obtain one from the client — either by registering an application (§3a) or by
scoping to an id you already hold with `forApplication()`.

## 3. Quick start

### 3a. First run — register the application

```ts
const app = await client.applications.register({
  name:             'acme.notifync.com',   // your domain — this is the natural key
  purgeWindowHours: 24,                    // how long messages are kept
  url:              'https://acme.example.com',
});

console.log(app.appId);   // ← store this; it is your appId from now on
```

`register` is idempotent by `name`: calling it again returns the existing
application rather than creating a second one, so it is safe to run on every
deploy. Store `app.appId` in your config alongside `baseUrl` and `env` — it does
not change.

### 3b. Every run — set up users, channels and messages

Construct the client, then scope it to your application:

```ts
const comms = client.forApplication(process.env.COMM_STACK_APP_ID!);

// Fail fast at boot if anything is misconfigured.
await comms.verifyAccess();

// A user
await comms.users.create({ userId: 'user-uuid-1', name: 'Priya Sharma' });

// A channel, and the user in it
const channel = await comms.channels.create({ channelType: 2, displayName: 'Ward A' });
await comms.members.add({ channelId: channel.channelId, userId: 'user-uuid-1' });

// A message
await comms.messages.sendToChannel({
  channelId: channel.channelId,
  sender:    'user-uuid-1',
  text:      'Shift starts at 9.',
});

// And read it back
const history = await comms.messages.channelHistory({
  channelId: channel.channelId,
  userId:    'user-uuid-1',
});

```

To go from registration straight to use in one process, scope the same client:

```ts
const app   = await client.applications.register({ name: 'acme.notifync.com' });
const comms = client.forApplication(app.appId);
```

`forApplication` returns a new client; the original stays unscoped and can still
register or inspect other applications.

### 3c. Receiving messages as they arrive

```ts
comms.realtime.on('directMessage', (m) => console.log(m.sender_name, m.text));
await comms.realtime.connect({ userId: 'user-uuid-1' });
```

No extra address and no port: the connection comes from the same `baseUrl`.
See §7.

## 4. Concepts

**Field names.** Every field is the platform's own column name, camel-cased:
`purge_window_hours` → `purgeWindowHours`, `read_at` → `readAt`,
`channel_id` → `channelId`. Nothing is renamed to a synonym, so a name you see
in the SDK is a name you can search for in the schema. Two conversions are
applied for convenience: timestamps arrive as `Date`, and `TINYINT(1)` flags
arrive as `boolean`.

**Applications.** The tenant boundary. Users, channels and messages all live
inside one application and nothing crosses between them. `comms.applications`
is the only namespace that works on an unscoped client; everything else throws
`INVALID_APPLICATION` until `forApplication()` has been used.

**Users.** You supply the identifier. CommStack never generates user ids, so you
can keep the ones your own system already uses.

**Acting user.** Many operations happen *on behalf of* someone — `sender`,
`userId`. This drives sender identity, unread counts and read receipts.

**Sessions.** Push-token binding, not presence. Register one when a user signs
in to your system and close it when they sign out. A session does *not* make a
user online — that requires a live connection from a handset.

**Delivery.** A send is accepted and delivered asynchronously, so a resolved
promise means *accepted*, never *delivered*. Reading history tells you what was
stored; the realtime stream (§7) tells you when something arrives.

**Errors.** Every failure is a `CommStackError` with a `code`. Switch on the
code, never on the message text.

```ts
import { CommStackError } from '@notify/commstack-sdk';

try {
  await comms.users.create({ userId: 'user-uuid-1' });
} catch (error) {
  if (error instanceof CommStackError && error.code === 'ALREADY_EXISTS') {
    // fine — carry on
  } else {
    throw error;
  }
}
```

| Code | HTTP status | Retryable | Meaning |
|---|---|---|---|
| `UNAUTHORIZED` | `401` | no | The access token was rejected. |
| `INVALID_APPLICATION` | `400` ¹ | no | `appId` is missing, malformed, or not registered on this server. |
| `INVALID_REQUEST` | `400` ¹ | no | Arguments were rejected. `error.details.fields` lists them where known. |
| `NOT_FOUND` | `404` | no | No such user, channel, member or message. |
| `ALREADY_EXISTS` | `409` | no | The resource is already present. |
| `ATTACHMENT_TOO_LARGE` | `413`, or `400` on a size message | no | The attachment exceeds the 50 MB limit. |
| `SERVER_ERROR` | `5xx`, or any unmapped status | **yes** | The service failed to handle the request. `error.details.status` carries the status. |
| `NETWORK_ERROR` | — no response | **yes** | The service could not be reached. |
| `TIMEOUT` | — no response | **yes** | No response within the configured timeout. |

¹ `INVALID_APPLICATION` and `INVALID_REQUEST` are also raised locally — before
any request is sent — when the client is not scoped to an application, or when
arguments fail validation. There is no HTTP status in that case.

A `200` response carrying `success: false` is treated as a `400`.

`error.retryable` is `true` for `SERVER_ERROR`, `NETWORK_ERROR` and `TIMEOUT`,
and `false` for everything else — use it to decide whether a retry is worth
attempting:

```ts
try {
  await comms.messages.sendDirect({ receiver, sender, text });
} catch (error) {
  if (error instanceof CommStackError && error.retryable) {
    await backoffAndRetry();
  } else {
    throw error;   // a caller mistake — retrying will not help
  }
}
```

---

## 5. API reference

Everything in this section is public and covered by the compatibility guarantees
for the 1.x line. Anything not documented here is internal and may change
without notice.

### 5.1 `new CommStack(options)`

| Option | Type | Required | Description |
|---|---|---|---|
| `baseUrl` | `string` | yes | Server hostname, e.g. `notcomprodeast.notifync.com`. The scheme, port and `/api/v1` path are supplied for you. |
| `env` | `'dev' \| 'production'` | yes | Which environment the server is. Selects the access token the SDK uses; any other value throws `INVALID_REQUEST`. |
| `timeout` | `number` | no | Request timeout in ms. Default `15000`. |

That is the entire constructor. There is no `appId` option — see
`forApplication` below.

The client is stateless — construct one and share it for the life of the process.

#### `forApplication(appId): CommStack`
A new client bound to `appId`, sharing this one's `baseUrl`, `env` and timeout.
Everything outside `applications` needs a scoped client.

#### `verifyAccess(): Promise<boolean>`
Confirms the credentials are accepted. Resolves `true`, or throws
`UNAUTHORIZED`. On a scoped client it also confirms the application resolves,
raising `INVALID_APPLICATION` if it does not. Call it at start-up
so misconfiguration surfaces at boot rather than on your first real operation.

---

### 5.2 `comms.applications`

The only namespace usable on an unscoped client.

#### `register(input): Promise<Application>`

| Field | Type | Required | Description |
|---|---|---|---|
| `name` | `string` | yes | Domain name, 3–255 characters. The natural key. |
| `purgeWindowHours` | `number` | no | Message retention in hours. Defaults to 24. |
| `url` | `string` | no | CommStack URL to record, max 255 characters. |
| `status` | `number` | no | `0` inactive, `1` active. Defaults to active. |

Idempotent by `name`, so this is safe on every deploy.

#### `get(appIdOrName): Promise<Application>`
Accepts either the application id or the domain name it was registered under.

#### `list({ search?, status? }): Promise<Application[]>`

#### `update(appId, { purgeWindowHours?, url? }): Promise<Application>`
Supply at least one field. Pass `url: null` to clear the stored URL.

**`Application`** — `appId`, `name`, `status`, `purgeWindowHours`, `url`,
`createdAt`, `updatedAt`.

> `register` and `get` throw `SERVER_ERROR` if the service returns an
> application without an `appId`, rather than handing back an unusable value
> that would fail later as `INVALID_APPLICATION`.

---

### 5.3 `comms.users`

#### `create({ userId, name?, role? }): Promise<User>`
`userId` is your identifier, unique per application. `role` defaults to
`mobile user`. Throws `ALREADY_EXISTS` if the id is taken.

#### `createMany(inputs): Promise<BulkCreateResult>`
Up to 100 per call. Partial success is **reported, not thrown**:

```ts
const result = await comms.users.createMany([
  { userId: 'user-1', name: 'Priya' },
  { userId: 'user-2', name: 'Arun'  },
]);
// { created: User[], skipped: string[], failed: [{ userId, error }] }
```

#### `list(): Promise<User[]>`
#### `get(userId): Promise<User>`
#### `update(userId, { name }): Promise<void>`
#### `remove(userId): Promise<void>`

#### `listActive({ userId, page?, limit? }): Promise<Page<ActiveUser> & { totalUnreadCount }>`
Users with a registered session, plus how many unread direct messages each has
sent to `userId`. `online` distinguishes those currently holding a live
connection from those merely logged in. `limit` defaults to 100, capped at 100.

**`User`** — `userId`, `name`, `role`, `online`, `createdAt`, `updatedAt`.
**`ActiveUser`** adds `unreadCount` and `handsetName`.

---

### 5.4 `comms.channels`

#### `create({ channelType, displayName? }): Promise<Channel>`
`channelType` is the stored category value. `displayName` is required for every
type except one-to-one. Creating a channel whose `displayName` already exists
returns the existing one rather than duplicating it.

#### `list({ channelType? }): Promise<Channel[]>`
`channelType` accepts a single value or an array.

#### `listForUser({ userId, page?, limit?, channelType? }): Promise<Page<SubscribedChannel> & { totalUnreadCount }>`
Channels that user belongs to, with their unread counts attached. This is the
call to drive a chat list.

```ts
const list = await comms.channels.listForUser({ userId: 'user-uuid-1', limit: 20 });
for (const c of list.items) {
  console.log(c.displayName, c.unreadCount, c.memberCount);
}
```

#### `get(channelId): Promise<Channel>`
#### `update(channelId, { displayName }): Promise<void>`
#### `remove(channelId): Promise<void>`
Removes the channel and its membership. Message history is retained.

#### `getDefaultGroup(): Promise<Channel | null>`
The application's default group, created lazily on first request.

#### `setAutoplayVoiceMessage({ channelId, userId, autoplayVoiceMessage }): Promise<void>`

**`Channel`** — `channelId`, `displayName`, `channelType`, `userId`,
`createdAt`, `updatedAt`.
**`SubscribedChannel`** adds `unreadCount`, `memberCount`, `autoplayVoiceMessage`.

---

### 5.5 `comms.members`

#### `add({ channelId, userId, autoplayVoiceMessage? }): Promise<ChannelMember>`

| Field | Type | Required | Description |
|---|---|---|---|
| `channelId` | UUID | Yes | Channel to join. |
| `userId` | UUID | Yes | User to add. Must already exist. |
| `autoplayVoiceMessage` | Boolean | No | Autoplay voice messages. Default true. |

Adds an **existing** user to a channel. Create the user with `users.create()`
first — adding an unregistered id throws `NOT_FOUND` rather than creating the
user silently. Adding someone who is already a member succeeds and returns the
current membership.

#### `addMany(inputs): Promise<BulkAddResult>`
`[{ channelId, userId }, …]` → `{ created, skipped, total }`.

#### `list({ channelId? }): Promise<ChannelMember[]>`
#### `get(channelMemberId): Promise<ChannelMember>`
#### `update(channelMemberId, { autoplayVoiceMessage?, lastViewAt? }): Promise<void>`
#### `remove({ channelId, userId }): Promise<void>`

**`ChannelMember`** — `channelMemberId`, `userId`, `channelId`,
`autoplayVoiceMessage`, `unreadCount`, `lastViewAt`, `createdAt`.

---

### 5.6 `comms.messages`

#### `sendToChannel(input): Promise<SendAck>`

| Field | Type | Required | Description |
|---|---|---|---|
| `channelId` | `string` | yes | Target channel. |
| `sender` | `string` | yes | Sender's user id. |
| `senderName` | `string` | no | Name recorded with the message; resolved from the directory if omitted. |
| `text` | `string` | one of | Message body. |
| `file` | `Attachment` | one of | File to send. |
| `type` | `'photo' \| 'voice' \| 'pdf'` | with `file` | Attachment type. |
| `duration` | `number` | for voice | Length in seconds. |

> **Delivery is asynchronous.** A resolved promise means the service *accepted*
> the message, not that it was delivered. A message addressed to a channel that
> does not exist is accepted and then discarded — call `channels.get()` first if
> that distinction matters. `SendAck.ackId` is a correlation id for log tracing;
> it is **not** a `messageId` and cannot be passed to `markAsRead()` or
> `getReadReceipt()`.

#### `sendDirect(input): Promise<SendAck>`
Same fields, with `receiver` in place of `channelId`. Delivered in real time when
the recipient is connected, and as a push notification when they are not. The
same asynchronous-delivery note applies.

```ts
// Text
await comms.messages.sendDirect({
  receiver: 'user-uuid-2',
  sender:   'user-uuid-1',
  text:     'Running ten minutes late.',
});

// Voice note from disk
await comms.messages.sendDirect({
  receiver: 'user-uuid-2',
  sender:   'user-uuid-1',
  type:     'voice',
  duration: 12,
  file:     { path: './handover.m4a' },
});

// Image from a buffer
await comms.messages.sendDirect({
  receiver: 'user-uuid-2',
  sender:   'user-uuid-1',
  type:     'photo',
  file:     { data: buffer, filename: 'chart.png', contentType: 'image/png' },
});
```

**`Attachment`** — supply either `path`, or `data` together with `filename`.
Optional `contentType`. Maximum 50 MB.

#### `channelHistory({ channelId, userId?, limit?, offset? }): Promise<Page<Message>>`
Newest first. Passing `userId` also clears that user's unread count for the
channel — omit it for a read-only fetch that leaves counters untouched.

#### `directHistory({ userId, otherUserId, limit?, offset? }): Promise<Page<Message>>`
The conversation between the two, newest first. Also marks it viewed for `userId`.

#### `get(messageId): Promise<Message>`
#### `list({ limit?, offset? }): Promise<Page<Message>>`
Every message in the application. Intended for exports and audits.

#### `markAsRead(messageId): Promise<void>`
Direct messages only. Throws `INVALID_REQUEST` for a channel message — channel
read state is maintained by `channelHistory()` and the delivery layer.

#### `getReadReceipt(messageId): Promise<ReadReceipt>`
`{ messageId, readAt, handsetName }`. `readAt` is `null` while unread.

#### `download(file): Promise<Buffer>`
Pass `Message.file`. Throws `INVALID_REQUEST` if the message has no attachment.

**`Message`** — `messageId`, `type`, `text`, `file`, `duration`, `sender`,
`senderName`, `receiver`, `channelId`, `sequence`, `readAt`, `createdAt`.

**`Page<T>`** — `items`, `total`, `limit`, `offset`, `hasMore`.

---

### 5.7 `comms.sessions`

#### `login({ userId, password, userName?, deviceToken?, deviceType?, handsetName? }): Promise<void>`
Binds the user's push token and device name, and lists them in
`users.listActive()`. Call once after the user authenticates in your system.

`password` is the shared login password — one value for every user of every
application, issued to you during onboarding. The call throws `NOT_FOUND` if
`userId` is not a registered user, and `UNAUTHORIZED` if the password does not
match; in both cases no session is opened.

This does **not** make the user online. A user registered this way appears with
`online: false` and receives messages as push notifications; `online: true`
requires a live connection from the mobile or browser client on a handset.

#### `logout(userId): Promise<void>`
Ends the session and stops push delivery.

---

### 5.8 `comms.realtime`

Live delivery. Sending is REST and only *acknowledges*; this is the connection
that tells you when something arrives. Full walkthrough in §7.

A connection is opened **as a user**, because the platform addresses messages to
people: who you connect as decides what you receive. It needs an application
scope, so use it on a client from `forApplication()`.

#### `connect(identity): Promise<void>`

| Field | Type | Required | Description |
|---|---|---|---|
| `userId` | `string` | yes | The user whose stream this connection carries. |
| `userName` | `string` | no | Name shown to others in presence. Defaults to `userId`. |
| `deviceToken` | `string` | no | Push token to bind for this session. |
| `deviceType` | `string` | no | `android`, `ios`, `web`. |
| `handsetName` | `string` | no | Device label surfaced on read receipts. |

Resolves once the connection is established, so a resolved promise means
*subscribed* — anything sent after it will arrive. Throws `INVALID_APPLICATION`
on an unscoped client, `INVALID_REQUEST` without a `userId`, `TIMEOUT` if the
server cannot be reached, and `NETWORK_ERROR` if it refuses. Calling it on an
already-open connection is a no-op, not an error.

Reconnection is automatic and indefinite once a connection has been established;
your handlers stay attached across it.

#### `on(event, handler): () => void`
Subscribe. Returns an unsubscribe function, which is usually tidier than keeping
the handler around to pass to `off`.

| Event | Handler receives |
|---|---|
| `message` | a channel message |
| `directMessage` | a one-to-one message |
| `presence` | the list of users now online |
| `connected` | *(no argument)* — the connection opened |
| `disconnected` | the reason, as a string |
| `error` | an `Error` |

Handlers may be registered **before** `connect()`; they are held and attached
when the socket opens, so there is no window in which an early message is missed.

A handler that throws does not stop the others running and does not take the
connection down — the exception is reported on the `error` event instead.

#### `off(event, handler): void`
Remove a handler registered with `on`.

#### `disconnect(): void`
Close the connection. Handlers are kept, so a later `connect()` resumes.

#### `connected: boolean` · `identity: RealtimeIdentity | null`
Whether the connection is open, and the user it was opened as.

**Message shape.** Realtime payloads are the platform's own wire format —
snake_case (`message_id`, `sender_name`, `channel_id`, `created_at`), unlike the
camelCase REST responses. They are passed through verbatim rather than mapped,
so a field the platform adds reaches you without waiting for an SDK release.

---

## 6. Pagination

Every paginated call returns the same envelope, so one helper covers all of them:

```ts
async function* everyMessage(channelId: string) {
  let offset = 0;
  for (;;) {
    const page = await comms.messages.channelHistory({ channelId, limit: 100, offset });
    yield* page.items;
    if (!page.hasMore) return;
    offset += page.items.length;
  }
}
```

## 7. Realtime

Reading history tells you what was stored. This tells you when something
arrives.

### 7.1 Receiving messages

```ts
const comms = new CommStack({ baseUrl, env }).forApplication(APP_ID);

comms.realtime.on('message',       (m) => console.log('channel:', m.text));
comms.realtime.on('directMessage', (m) => console.log('dm:', m.text));
comms.realtime.on('presence',      (users) => console.log(users.length, 'online'));

await comms.realtime.connect({ userId: 'user-uuid-1', userName: 'Priya Sharma' });
```

That is the whole setup. No second address, no port, no extra firewall rule —
the connection is derived from the same `baseUrl` your REST calls already use.

Register handlers **before** connecting. They are held and attached when the
socket opens, so nothing arriving in the opening moments is missed.

### 7.2 One connection per user

A connection carries one user's messages, because that is how the platform
addresses them. A server needing several users' streams opens a client each:

```ts
const streams = new Map<string, CommStack>();

for (const userId of userIds) {
  const scoped = new CommStack({ baseUrl, env }).forApplication(APP_ID);
  scoped.realtime.on('directMessage', (m) => handle(userId, m));
  await scoped.realtime.connect({ userId });
  streams.set(userId, scoped);
}
```

That is fine for tens of users. If you need every message in an application over
a single connection, ask us — that is a platform-side subscription, not
something the SDK can synthesise.

### 7.3 Giving browsers and mobile apps live messages

**Do not put this SDK in a browser.** It carries your access token, and anything
a browser holds is readable by whoever is using it.

Run it on your server and relay:

```
browser ──your transport──► your server ──CommStack SDK realtime──► CommStack
```

Your server holds the connection and the token; your clients connect to *you*,
authenticated however you already authenticate them. You decide who sees what,
and your users never need a CommStack address at all.

A worked example, using Socket.IO on your own server:

```ts
io.use(async (browser, next) => {
  const { userId, userName } = browser.handshake.auth;
  if (!userId) return next(new Error('userId is required'));

  const comms = client.forApplication(APP_ID);
  comms.realtime.on('message',       (m) => browser.emit('message', m));
  comms.realtime.on('directMessage', (m) => browser.emit('directMessage', m));

  await comms.realtime.connect({ userId, userName });
  browser.data.comms = comms;
  next();
});

io.on('connection', (browser) => {
  browser.on('disconnect', () => browser.data.comms?.realtime.disconnect());
});
```

> Open the upstream connection in **middleware**, as above, not in the
> `connection` handler. Middleware runs before the browser is told it is
> connected, so by the time your client's own `connect` fires the CommStack
> stream is already live. Do it in `connection` instead and there is a window —
> a few hundred milliseconds — in which your client believes it is subscribed
> and messages are silently dropped.

### 7.4 What to design for

- **Sending stays REST.** `messages.sendToChannel` / `sendDirect` acknowledge;
  they do not deliver. Delivery arrives on this stream.
- **Reconnects are automatic** once a connection has been established, and your
  handlers survive them. A reconnect does **not** replay what was missed while
  it was down — backfill with `messages.channelHistory()` / `directHistory()`
  if a gap would matter to you.
- **Order by `sequence` and `created_at`**, not by arrival.
- **Close it.** Call `disconnect()` when a user goes away, or you will hold a
  connection for everyone who ever signed in.

---

## 8. Troubleshooting

| Symptom | Cause |
|---|---|
| `INVALID_APPLICATION`, message mentions `forApplication` | The client is not scoped. Call `forApplication(appId)` first. |
| `INVALID_APPLICATION` on every call | `appId` wrong, or the application was never registered. |
| `UNAUTHORIZED` on every call | `env` names an environment the server does not accept — a `dev` client pointed at a production host, or the reverse. Check `env` against the host in `baseUrl`. |
| `INVALID_REQUEST` mentioning `env`, at construction | `env` is missing or misspelt. It must be exactly `'dev'` or `'production'`. |
| `NETWORK_ERROR` at start-up | `baseUrl` points somewhere unreachable. The message names the address the SDK resolved — check the hostname is right and reachable from where you are running. |
| `INVALID_REQUEST: duration is required` | Voice messages need `duration` in seconds. |
| Message sent, never arrives | The channel or recipient does not exist. Sends are accepted asynchronously and invalid targets are discarded — verify with `channels.get()` / `users.get()`. |
| `TIMEOUT` on large uploads | Raise `timeout`; the default 15 s is tuned for text. |
| `INVALID_REQUEST` naming `COMM_STACK_SDK_TOKEN`, at construction | No token in the environment. Set it, or pass `sdkToken`. See §2. |
| `INVALID_APPLICATION` from `realtime.connect` | Realtime needs a scoped client. Call `forApplication(appId)` first. |
| `TIMEOUT` / `NETWORK_ERROR` from `realtime.connect` | Realtime is not reachable at that `baseUrl`. Confirm the host is right and that realtime is enabled on the deployment. |
| Connected, but no messages arrive | You are connected as a user the messages are not addressed to. A connection carries one user's stream — check the `userId`. |
| Messages missed right after connecting | Register handlers before `connect()`, and if you relay to your own clients, open the upstream connection in middleware — see §7.3. |

## 9. Support

Contact your Notify representative, quoting the SDK version from
`package.json` and the `code` from any `CommStackError` you are seeing.
