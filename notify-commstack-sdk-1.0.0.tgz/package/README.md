# CommStack SDK for Node.js

Server-side client for the CommStack messaging platform. Register applications
and users, manage channels and membership, send messages and read history — all
from your own backend.

Confidential. This package and the documentation it contains are proprietary and
are provided under the terms of the applicable licence agreement.

---

## 1. Requirements and installation

| Requirement | Minimum |
|---|---|
| Node.js | 18.0 |
| TypeScript (optional) | 5.0 |

You were sent a single file, `notify-commstack-sdk-1.0.0.tgz`. It contains the
whole SDK — every operation described in this guide. Put it somewhere in your
project and install it:

```bash
npm install ./notify-commstack-sdk-1.0.0.tgz
```

That adds it to your `package.json` like any other dependency:

```json
"dependencies": {
  "@notify/commstack-sdk": "file:notify-commstack-sdk-1.0.0.tgz"
}
```

Types are bundled — no separate `@types` package is needed, and no other
CommStack package is required.

<details>
<summary>Building the tarball from source</summary>

```bash
cd sdk
npm install
npm run build:release   # bundled, minified dist/index.js + type declarations
npm pack                # → notify-commstack-sdk-1.0.0.tgz
```

`npm run build` produces readable per-module output instead, which is what the
test suite uses. Run `npm test` to exercise the SDK end to end against an
in-memory server, or point it at a real deployment:

```bash
COMMSTACK_BASE_URL=notcomprodeast.notifync.com \
COMMSTACK_SDK_TOKEN=… \
npm test
```
</details>

## 2. Setup

Alongside the package you were given two values. They are the whole
configuration — there is nothing else to set.

| Value | What it is |
|---|---|
| **`baseUrl`** | The CommStack server you have been allocated, e.g. `notcomprodeast.notifync.com`. |
| **`sdkToken`** | Your access token. Treat it as a password. |

Put them in your environment rather than in code:

```bash
# .env — never commit this file
COMM_STACK_BASE_URL=notcomprodeast.notifync.com
COMM_STACK_SDK_TOKEN=<the token you were issued>
```

```ts
import { CommStack } from '@notify/commstack-sdk';

const client = new CommStack({
  baseUrl:  process.env.COMM_STACK_BASE_URL!,
  sdkToken: process.env.COMM_STACK_SDK_TOKEN!,
});

await client.verifyAccess();   // throws immediately if either value is wrong
```

The token is server-side only. Never ship it to a browser, a mobile binary, or
anything else an end user can read.

### How requests are routed

Supply the hostname alone. A CommStack deployment serves each kind of traffic on
its own port, and the SDK fills in the ones it needs:

| Traffic | Port | Used by |
|---|---|---|
| REST API | `5203` | This SDK. |
| WebSocket | `5212` | Realtime clients, plaintext. |
| WebSocket over TLS | `5213` | Realtime clients, e.g. `wss://notcomprodeast.notifync.com:5213/`. |

This SDK talks to the REST API only, so from `notcomprodeast.notifync.com` it
builds every request as `https://notcomprodeast.notifync.com:5203/api/v1/{endpoint}`.
Realtime connections are made by the mobile and browser SDKs, not this one.

A bare hostname means "a standard deployment", so scheme, port and prefix are all
supplied. The first four rows below are identical:

| You supply | The SDK calls |
|---|---|
| `notcomprodeast.notifync.com` | `https://notcomprodeast.notifync.com:5203/api/v1/…` |
| `notcomprodeast.notifync.com/` | `https://notcomprodeast.notifync.com:5203/api/v1/…` |
| `https://notcomprodeast.notifync.com` | `https://notcomprodeast.notifync.com:5203/api/v1/…` |
| `notcomprodeast.notifync.com:5203` | `https://notcomprodeast.notifync.com:5203/api/v1/…` |
| `notcomprodeast.notifync.com:8080` | `https://notcomprodeast.notifync.com:8080/api/v1/…` |
| `http://internal-host:5203` | `http://internal-host:5203/api/v1/…` |
| `https://api.example.com/comms/v1` | `https://api.example.com/comms/v1/…` |

Any hostname behaves the same way — substitute whichever server you were
allocated.

Writing a **port** or a **path** means you are describing the layout yourself,
and nothing is injected over it. That is what makes the last row work: a
reverse-proxied deployment on 443 keeps its own path and is not forced onto
5203. The corollary is that if you write a path but no port, you get port 443 —
so give the port explicitly unless the deployment really is proxied.

Everything routes to that one server. A client cannot be retargeted after it is
constructed, so if you integrate with more than one deployment, build one client
per server.

### What about an application id?

`appId` is **not** a constructor option. Applications belong to a server, so you
obtain one from the client — either by registering an application (§3a) or by
scoping to an id you already hold with `forApplication()`.

## 3. Quick start

### 3a. First run — register the application

```ts
const app = await client.applications.register({
  name:             'acme.notifync.com',   // your domain — this is the natural key
  purgeWindowHours: 24,                    // how long messages are kept
  url:              'https://acme.example.com',
});

console.log(app.appId);   // ← store this; it is your appId from now on
```

`register` is idempotent by `name`: calling it again returns the existing
application rather than creating a second one, so it is safe to run on every
deploy. Store `app.appId` in your config alongside the token — it does not change.

### 3b. Every run — set up users, channels and messages

Construct the client, then scope it to your application:

```ts
const comms = client.forApplication(process.env.COMM_STACK_APP_ID!);

// Fail fast at boot if anything is misconfigured.
await comms.verifyAccess();

// A user
await comms.users.create({ userId: 'user-uuid-1', name: 'Priya Sharma' });

// A channel, and the user in it
const channel = await comms.channels.create({ channelType: 2, displayName: 'Ward A' });
await comms.members.add({ channelId: channel.channelId, userId: 'user-uuid-1' });

// A message
await comms.messages.sendToChannel({
  channelId: channel.channelId,
  sender:    'user-uuid-1',
  text:      'Shift starts at 9.',
});

// And read it back
const history = await comms.messages.channelHistory({
  channelId: channel.channelId,
  userId:    'user-uuid-1',
});
```

To go from registration straight to use in one process, scope the same client:

```ts
const app   = await client.applications.register({ name: 'acme.notifync.com' });
const comms = client.forApplication(app.appId);
```

`forApplication` returns a new client; the original stays unscoped and can still
register or inspect other applications.

## 4. Concepts

**Field names.** Every field is the platform's own column name, camel-cased:
`purge_window_hours` → `purgeWindowHours`, `read_at` → `readAt`,
`channel_id` → `channelId`. Nothing is renamed to a synonym, so a name you see
in the SDK is a name you can search for in the schema. Two conversions are
applied for convenience: timestamps arrive as `Date`, and `TINYINT(1)` flags
arrive as `boolean`.

**Applications.** The tenant boundary. Users, channels and messages all live
inside one application and nothing crosses between them. `comms.applications`
is the only namespace that works on an unscoped client; everything else throws
`INVALID_APPLICATION` until `forApplication()` has been used.

**Users.** You supply the identifier. CommStack never generates user ids, so you
can keep the ones your own system already uses.

**Acting user.** Many operations happen *on behalf of* someone — `sender`,
`userId`. This drives sender identity, unread counts and read receipts.

**Sessions.** Push-token binding, not presence. Register one when a user signs
in to your system and close it when they sign out. A session does *not* make a
user online — that requires a live realtime connection, which this SDK does not
open (see §2).

**Errors.** Every failure is a `CommStackError` with a `code`. Switch on the
code, never on the message text.

```ts
import { CommStackError } from '@notify/commstack-sdk';

try {
  await comms.users.create({ userId: 'user-uuid-1' });
} catch (error) {
  if (error instanceof CommStackError && error.code === 'ALREADY_EXISTS') {
    // fine — carry on
  } else {
    throw error;
  }
}
```

| Code | HTTP status | Retryable | Meaning |
|---|---|---|---|
| `UNAUTHORIZED` | `401` | no | The access token was rejected. |
| `INVALID_APPLICATION` | `400` ¹ | no | `appId` is missing, malformed, or not registered on this server. |
| `INVALID_REQUEST` | `400` ¹ | no | Arguments were rejected. `error.details.fields` lists them where known. |
| `NOT_FOUND` | `404` | no | No such user, channel, member or message. |
| `ALREADY_EXISTS` | `409` | no | The resource is already present. |
| `ATTACHMENT_TOO_LARGE` | `413`, or `400` on a size message | no | The attachment exceeds the 50 MB limit. |
| `SERVER_ERROR` | `5xx`, or any unmapped status | **yes** | The service failed to handle the request. `error.details.status` carries the status. |
| `NETWORK_ERROR` | — no response | **yes** | The service could not be reached. |
| `TIMEOUT` | — no response | **yes** | No response within the configured timeout. |

¹ `INVALID_APPLICATION` and `INVALID_REQUEST` are also raised locally — before
any request is sent — when the client is not scoped to an application, or when
arguments fail validation. There is no HTTP status in that case.

A `200` response carrying `success: false` is treated as a `400`.

`error.retryable` is `true` for `SERVER_ERROR`, `NETWORK_ERROR` and `TIMEOUT`,
and `false` for everything else — use it to decide whether a retry is worth
attempting:

```ts
try {
  await comms.messages.sendDirect({ receiver, sender, text });
} catch (error) {
  if (error instanceof CommStackError && error.retryable) {
    await backoffAndRetry();
  } else {
    throw error;   // a caller mistake — retrying will not help
  }
}
```

---

## 5. API reference

Everything in this section is public and covered by the compatibility guarantees
for the 1.x line. Anything not documented here is internal and may change
without notice.

### 5.1 `new CommStack(options)`

| Option | Type | Required | Description |
|---|---|---|---|
| `baseUrl` | `string` | yes | Server hostname, e.g. `notcomprodeast.notifync.com`. Scheme, port `5203` and `/api/v1` path are supplied for you. |
| `sdkToken` | `string` | yes | SDK token issued during onboarding. |
| `timeout` | `number` | no | Request timeout in ms. Default `15000`. |

That is the entire constructor. There is no `appId` option — see
`forApplication` below.

The client is stateless — construct one and share it for the life of the process.

#### `forApplication(appId): CommStack`
A new client bound to `appId`, sharing this one's `baseUrl`, token and timeout.
Everything outside `applications` needs a scoped client.

#### `verifyAccess(): Promise<boolean>`
Confirms the credentials are accepted. Resolves `true`, or throws
`UNAUTHORIZED`. On a scoped client it also confirms the application resolves,
raising `INVALID_APPLICATION` if it does not. Call it at start-up
so misconfiguration surfaces at boot rather than on your first real operation.

---

### 5.2 `comms.applications`

The only namespace usable on an unscoped client.

#### `register(input): Promise<Application>`

| Field | Type | Required | Description |
|---|---|---|---|
| `name` | `string` | yes | Domain name, 3–255 characters. The natural key. |
| `purgeWindowHours` | `number` | no | Message retention in hours. Defaults to 24. |
| `url` | `string` | no | CommStack URL to record, max 255 characters. |
| `status` | `number` | no | `0` inactive, `1` active. Defaults to active. |

Idempotent by `name`.

#### `get(appIdOrName): Promise<Application>`
Accepts either the application id or the domain name it was registered under.

#### `list({ search?, status? }): Promise<Application[]>`

#### `update(appId, { purgeWindowHours?, url? }): Promise<Application>`
Supply at least one field. Pass `url: null` to clear the stored URL.

**`Application`** — `appId`, `name`, `status`, `purgeWindowHours`, `url`,
`createdAt`, `updatedAt`.

> `register` and `get` throw `SERVER_ERROR` if the service returns an
> application without an `appId`, rather than handing back an unusable value
> that would fail later as `INVALID_APPLICATION`.

---

### 5.3 `comms.users`

#### `create({ userId, name?, role? }): Promise<User>`
`userId` is your identifier, unique per application. `role` defaults to
`mobile user`. Throws `ALREADY_EXISTS` if the id is taken.

#### `createMany(inputs): Promise<BulkCreateResult>`
Up to 100 per call. Partial success is **reported, not thrown**:

```ts
const result = await comms.users.createMany([
  { userId: 'user-1', name: 'Priya' },
  { userId: 'user-2', name: 'Arun'  },
]);
// { created: User[], skipped: string[], failed: [{ userId, error }] }
```

#### `list(): Promise<User[]>`
#### `get(userId): Promise<User>`
#### `update(userId, { name }): Promise<void>`
#### `remove(userId): Promise<void>`

#### `listActive({ userId, page?, limit? }): Promise<Page<ActiveUser> & { totalUnreadCount }>`
Users with a registered session, plus how many unread direct messages each has
sent to `userId`. `online` distinguishes those currently holding a realtime
connection from those merely logged in. `limit` defaults to 100, capped at 100.

**`User`** — `userId`, `name`, `role`, `online`, `createdAt`, `updatedAt`.
**`ActiveUser`** adds `unreadCount` and `handsetName`.

---

### 5.4 `comms.channels`

#### `create({ channelType, displayName? }): Promise<Channel>`
`channelType` is the stored category value. `displayName` is required for every
type except one-to-one. Creating a channel whose `displayName` already exists
returns the existing one rather than duplicating it.

#### `list({ channelType? }): Promise<Channel[]>`
`channelType` accepts a single value or an array.

#### `listForUser({ userId, page?, limit?, channelType? }): Promise<Page<SubscribedChannel> & { totalUnreadCount }>`
Channels that user belongs to, with their unread counts attached. This is the
call to drive a chat list.

```ts
const list = await comms.channels.listForUser({ userId: 'user-uuid-1', limit: 20 });
for (const c of list.items) {
  console.log(c.displayName, c.unreadCount, c.memberCount);
}
```

#### `get(channelId): Promise<Channel>`
#### `update(channelId, { displayName }): Promise<void>`
#### `remove(channelId): Promise<void>`
Removes the channel and its membership. Message history is retained.

#### `getDefaultGroup(): Promise<Channel | null>`
The application's default group, created lazily on first request.

#### `setAutoplayVoiceMessage({ channelId, userId, autoplayVoiceMessage }): Promise<void>`

**`Channel`** — `channelId`, `displayName`, `channelType`, `userId`,
`createdAt`, `updatedAt`.
**`SubscribedChannel`** adds `unreadCount`, `memberCount`, `autoplayVoiceMessage`.

---

### 5.5 `comms.members`

#### `add({ channelId, userId, autoplayVoiceMessage? }): Promise<ChannelMember>`

| Field | Type | Required | Description |
|---|---|---|---|
| `channelId` | UUID | Yes | Channel to join. |
| `userId` | UUID | Yes | User to add. Must already exist. |
| `autoplayVoiceMessage` | Boolean | No | Autoplay voice messages. Default true. |

Adds an **existing** user to a channel. Create the user with `users.create()`
first — adding an unregistered id throws `NOT_FOUND` rather than creating the
user silently. Adding someone who is already a member succeeds and returns the
current membership.

#### `addMany(inputs): Promise<BulkAddResult>`
`[{ channelId, userId }, …]` → `{ created, skipped, total }`.

#### `list({ channelId? }): Promise<ChannelMember[]>`
#### `get(channelMemberId): Promise<ChannelMember>`
#### `update(channelMemberId, { autoplayVoiceMessage?, lastViewAt? }): Promise<void>`
#### `remove({ channelId, userId }): Promise<void>`

**`ChannelMember`** — `channelMemberId`, `userId`, `channelId`,
`autoplayVoiceMessage`, `unreadCount`, `lastViewAt`, `createdAt`.

---

### 5.6 `comms.messages`

#### `sendToChannel(input): Promise<SendAck>`

| Field | Type | Required | Description |
|---|---|---|---|
| `channelId` | `string` | yes | Target channel. |
| `sender` | `string` | yes | Sender's user id. |
| `senderName` | `string` | no | Name recorded with the message; resolved from the directory if omitted. |
| `text` | `string` | one of | Message body. |
| `file` | `Attachment` | one of | File to send. |
| `type` | `'photo' \| 'voice' \| 'pdf'` | with `file` | Attachment type. |
| `duration` | `number` | for voice | Length in seconds. |

> **Delivery is asynchronous.** A resolved promise means the service *accepted*
> the message, not that it was delivered. A message addressed to a channel that
> does not exist is accepted and then discarded — call `channels.get()` first if
> that distinction matters. `SendAck.ackId` is a correlation id for log tracing;
> it is **not** a `messageId` and cannot be passed to `markAsRead()` or
> `getReadReceipt()`.

#### `sendDirect(input): Promise<SendAck>`
Same fields, with `receiver` in place of `channelId`. Delivered in real time when
the recipient is connected, and as a push notification when they are not. The
same asynchronous-delivery note applies.

```ts
// Text
await comms.messages.sendDirect({
  receiver: 'user-uuid-2',
  sender:   'user-uuid-1',
  text:     'Running ten minutes late.',
});

// Voice note from disk
await comms.messages.sendDirect({
  receiver: 'user-uuid-2',
  sender:   'user-uuid-1',
  type:     'voice',
  duration: 12,
  file:     { path: './handover.m4a' },
});

// Image from a buffer
await comms.messages.sendDirect({
  receiver: 'user-uuid-2',
  sender:   'user-uuid-1',
  type:     'photo',
  file:     { data: buffer, filename: 'chart.png', contentType: 'image/png' },
});
```

**`Attachment`** — supply either `path`, or `data` together with `filename`.
Optional `contentType`. Maximum 50 MB.

#### `channelHistory({ channelId, userId?, limit?, offset? }): Promise<Page<Message>>`
Newest first. Passing `userId` also clears that user's unread count for the
channel — omit it for a read-only fetch that leaves counters untouched.

#### `directHistory({ userId, otherUserId, limit?, offset? }): Promise<Page<Message>>`
The conversation between the two, newest first. Also marks it viewed for `userId`.

#### `get(messageId): Promise<Message>`
#### `list({ limit?, offset? }): Promise<Page<Message>>`
Every message in the application. Intended for exports and audits.

#### `markAsRead(messageId): Promise<void>`
Direct messages only. Throws `INVALID_REQUEST` for a channel message — channel
read state is maintained by `channelHistory()` and the realtime layer.

#### `getReadReceipt(messageId): Promise<ReadReceipt>`
`{ messageId, readAt, handsetName }`. `readAt` is `null` while unread.

#### `download(file): Promise<Buffer>`
Pass `Message.file`. Throws `INVALID_REQUEST` if the message has no attachment.

**`Message`** — `messageId`, `type`, `text`, `file`, `duration`, `sender`,
`senderName`, `receiver`, `channelId`, `sequence`, `readAt`, `createdAt`.

**`Page<T>`** — `items`, `total`, `limit`, `offset`, `hasMore`.

---

### 5.7 `comms.sessions`

#### `login({ userId, password, userName?, deviceToken?, deviceType?, handsetName? }): Promise<void>`
Binds the user's push token and device name, and lists them in
`users.listActive()`. Call once after the user authenticates in your system.

`password` is the shared login password — one value for every user of every
application, issued to you during onboarding. The call throws `NOT_FOUND` if
`userId` is not a registered user, and `UNAUTHORIZED` if the password does not
match; in both cases no session is opened.

This does **not** make the user online. A user registered this way appears with
`online: false` and receives messages as push notifications; `online: true`
requires a live realtime connection, opened by the mobile or browser SDK.

#### `logout(userId): Promise<void>`
Ends the session and stops push delivery.

---

## 6. Pagination

Every paginated call returns the same envelope, so one helper covers all of them:

```ts
async function* everyMessage(channelId: string) {
  let offset = 0;
  for (;;) {
    const page = await comms.messages.channelHistory({ channelId, limit: 100, offset });
    yield* page.items;
    if (!page.hasMore) return;
    offset += page.items.length;
  }
}
```

## 7. Troubleshooting

| Symptom | Cause |
|---|---|
| `INVALID_APPLICATION`, message mentions `forApplication` | The client is not scoped. Call `forApplication(appId)` first. |
| `INVALID_APPLICATION` on every call | `appId` wrong, or the application was never registered. |
| `UNAUTHORIZED` on every call | `sdkToken` wrong or truncated. Check for stray whitespace. |
| `NETWORK_ERROR` at start-up | `baseUrl` points somewhere unreachable. The message names the resolved address — check its port and path. |
| `INVALID_REQUEST: duration is required` | Voice messages need `duration` in seconds. |
| Message sent, never arrives | The channel or recipient does not exist. Sends are accepted asynchronously and invalid targets are discarded — verify with `channels.get()` / `users.get()`. |
| `TIMEOUT` on large uploads | Raise `timeout`; the default 15 s is tuned for text. |

## 8. Support

Contact your Notify representative, quoting the SDK version from
`package.json` and the `code` from any `CommStackError` you are seeing.
